# PrograIV_semi_2025_CR29
Codigos y ejemplos de programacion IV semipresencial 2025.
